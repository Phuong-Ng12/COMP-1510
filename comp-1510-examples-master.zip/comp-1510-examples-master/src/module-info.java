module ca.bcit.comp1510.examples {
	requires org.junit.jupiter.api;
	requires org.junit.platform.runner;
    requires org.junit.jupiter.params;
}