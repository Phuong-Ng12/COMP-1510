module COMP1510Lab02NguyenP {
}