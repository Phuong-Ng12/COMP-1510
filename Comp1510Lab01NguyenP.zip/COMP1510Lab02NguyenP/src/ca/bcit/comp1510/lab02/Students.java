/**
 * 
 */
package ca.bcit.comp1510.lab02;

/**
 * A Table of Student Grades.
 * @author Phuong
 * @version 1.0
 */
public class Students {

    /**
     * A Table of Student Grades.
     * @param args
     *          unused
     */
    public static void main(String[] args) {
        System.out.println("//////////////////\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\");
        System.out.println("==         Student Points          ==");
        System.out.println("\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\\//////////////////");
        System.out.println("Name\tLab\tBonus\tTotal");
        System.out.println("----\t---\t-----\t-----");
        System.out.println("Joe\t43\t7\t50");
        System.out.println("William\t50\t8\t58");
        System.out.println("MarySue\t39\t10\t49");
        System.out.println("Peng\t87\t6\t93");
        System.out.println("Kwon\t99\t0\t99");
        

    }

}
