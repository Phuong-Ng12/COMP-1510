module COMP1510Lab04NguyenP {
}